import sqlite3
from datetime import datetime

import click
from flask import current_app, g
from werkzeug.security import generate_password_hash

def get_db():
    if 'questions_db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row

        return g.db

def close_db(e=None):
    db = g.pop('questions_db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()

    with current_app.open_resource('questions_schema.sql') as f:
        db.executescript(f.read().decode('utf8'))


@click.command('init-db')
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    create_default_users()
    click.echo('Initialized the database - questions and users.')

def create_default_users():
    users = [('Instructor', generate_password_hash('Unsecured9')), 
             ('Student', generate_password_hash('password')),
             ('Dev', generate_password_hash('Shrimp5-Ageless9'))]
    for user in users:
        g.db.execute("INSERT INTO user (username, password) VALUES (?, ?)",
               user,
               )
        g.db.commit()

sqlite3.register_converter(
    "timestamp", lambda v: datetime.fromisoformat(v.decode())
)

#Register with the application
def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)