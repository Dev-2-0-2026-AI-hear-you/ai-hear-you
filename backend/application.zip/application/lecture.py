from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)

from werkzeug.exceptions import abort

from application import questions_db
from application.auth import login_required
from . import transcript
from . import questions_db as q_db

bp = Blueprint('lecture', __name__)

@bp.route('/')
def index():
    # q_db = questions_db.get_db()
    # # questions = q_db.execute(
    # #     'SELECT q.id, author_id, body, created, username'
    # #     ' FROM question q JOIN user u ON q.author_id = u.id'
    # #     ' ORDER BY created DESC'
    # # ).fetchall()
    return redirect(url_for('lecture.student'))

@bp.route('/student')
def student():
    if request.method == 'POST':
        question_text = request.form['question-input']

        db = q_db.get_db()
        error = None

        if not question_text:
            error = 'Question text is required.'

        if error is None:
            db.execute(
                'INSERT INTO questions (question_text) VALUES (?)',
                (question_text,)
            )
            db.commit()


    #when the start button is called
    transcript.start()

    #when the stop button is called
    transcript.stop()

    return render_template('lecture/student.html')
